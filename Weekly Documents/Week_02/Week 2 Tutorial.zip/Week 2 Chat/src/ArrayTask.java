import java.util.Scanner;

public class ArrayTask {
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number days in a month");	
		int days=sc.nextInt();
		double max[] = new double [days];
		double min[] = new double [days];
		double max_temp, min_temp, total_max=0.0, total_min=0.0;
		for (int i=0;i< max.length;i++){
			System.out.println("enter max temp");	
			max_temp=sc.nextDouble();
			max[i]=max_temp;
			total_max+=max[i];
			System.out.println("enter min temp");	
			min[i]=sc.nextDouble();
			total_min+=min[i];
		}
		
			System.out.println("average Maximum is " +total_max/days);	
			
			
			System.out.println("average Minimum is " +total_min/days);		
			
			
		
		//Highest Maximum
			double Highest_max= max[0];
			for (int i=1;i< max.length;i++){
				if( max[i]>Highest_max){
					Highest_max=max[i];
				}
			}
			System.out.println("Highest Maximum is " +Highest_max);	
		
			//Lowest Maximum
			
			double lowest_max= max[0];
			for (int i=1;i< max.length;i++){
				if( max[i]<lowest_max){
					lowest_max=max[i];
				}
			}
			System.out.println("Lowest Maximum is " +lowest_max);	
		
		//------------------------------------------------------
			
	
	//Highest Min
		double Highest_min= min[0];
		for (int i=1;i< min.length;i++){
			if( min[i]>Highest_min){
				Highest_min=min[i];
			}
		}
		System.out.println("Lowest Minimum is " +Highest_min);	
	
		//Lowest Min
		
		double lowest_min= min[0];
		for (int i=1;i< min.length;i++){
			if( min[i]<lowest_min){
				lowest_min=min[i];
			}
		}
		System.out.println("Lowest Minimum is " +lowest_min);	
		
		
		int count=0;
		
		for (int i=0;i< max.length;i++){
			
			if (max[i]>total_max/days)
				count++;
		
		}
		
		System.out.println("The number of days above average " +count);
	
	}
		
		
	
	
	
	
	
	
}
