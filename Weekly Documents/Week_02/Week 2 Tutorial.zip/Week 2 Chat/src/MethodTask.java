import java.util.Scanner;

public class MethodTask {

	public static void main(String args[]) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter number days in a month");	
		int days=sc.nextInt();
		double max[] = new double [days];
		double min[] = new double [days];
		double max_temp, min_temp, total_max=0.0, total_min=0.0;
		for (int i=0;i< max.length;i++){
			System.out.println("enter max temp");	
			max_temp=sc.nextDouble();
			max[i]=max_temp;
			total_max+=max[i];
			System.out.println("enter min temp");	
			min[i]=sc.nextDouble();
			total_min+=min[i];
		}
		
		double max_average= Average(max);
		System.out.println("average Maximum is " +max_average);	

		double min_average= Average(min);
		System.out.println("average Maximum is " +min_average);	
		
		
		double Highest_max= HMaximumTemp(max);
		System.out.println("Highest Maximum is " +Highest_max);	
		
		double Lowest_max= LMaximumTemp(min) ;
		System.out.println("Lowest Maximum is " +Lowest_max);	
		
		double Highest_min= HMinimumTemp(min);
		System.out.println("Highest Minimum is " +Highest_min);
		
		double Lowest_min= LMinimumTemp(min);
		System.out.println("Lowest Minimum is " +Lowest_min);
		
		int numberOfdays= daysAboveAvg(max);
		System.out.println("The number of days above average " +numberOfdays);
		
	}
	
	
	public static double Average( double arr[]) 
	{
		double total=0.0;
		for (int i=0;i< arr.length;i++){
			total+=arr[i];
		}
		return total/arr.length;
		
		
	}
	
	
	public static double HMaximumTemp(double arr[])
	{
		double H_max= arr[0];
		for (int i=1;i< arr.length;i++){
			if( arr[i]>H_max){
				H_max=arr[i];
			}	
	}
		return H_max;
   }
	
	
	public static double LMaximumTemp(double arr[])
	{
		double L_max= arr[0];
		for (int i=1;i< arr.length;i++){
			if( arr[i]>L_max){
				L_max=arr[i];
			}	
	}
		return L_max;
   }
	
	public static double HMinimumTemp(double arr[])
	{
		double H_min= arr[0];
		for (int i=1;i< arr.length;i++){
			if( arr[i]<H_min){
				H_min=arr[i];
			}	
	}
		return H_min;
   }
	
	public static double LMinimumTemp(double arr[])
	{
		double L_min= arr[0];
		for (int i=1;i< arr.length;i++){
			if( arr[i]>L_min){
				L_min=arr[i];
			}	
	}
		return L_min;
   }
	
	public static int daysAboveAvg(double arr[])
	{
		int count=0; 
		double avg= Average(arr);
		for (int i=0;i< arr.length;i++){
			if(arr[i]>avg)
		   count++;
		}
		return count;
	}
	
	
}
