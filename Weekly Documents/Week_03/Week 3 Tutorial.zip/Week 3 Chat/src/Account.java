
public class Account
{
  
   private String accountID;  
   private String name;
   private double balance; 
   private String telNo; 
   private String TaxFileNo;
   
//constructor
   public Account(String accountID, String name, double amount, String telNo)
   {
      
      this.accountID = accountID; 
      this.name = name;
      this.balance = amount;
      this.telNo=telNo;
   }

 
   public String getAccountID()
   {
      return accountID;
   }

   public double getBalance()
   {
      return balance;
   }
   public String getTaxFileNumber()
   {
      return TaxFileNo;
   }
   public void setTaxFileNumber(String FN)
   {
	   this.TaxFileNo=FN;
   }
   
   public void setTelNumber(String TL)
   {
	   this.telNo=TL;
   }

 
   public void setName(String name)
   {
      if (name == null || name.isEmpty())
      {
         System.out.println("Error - name cannot be null or empty!");
      }
      else
      {
         this.name = name;
      }
  
   }

   
   public void deposit(double amount)
   {
      this.balance += amount;  
   }

  
   public boolean withdraw(double amount)
   {
     
      if (amount > balance)
      {
         return false;
      }
      else
      {
         this.balance = this.balance - amount;
         return true; 
      }

   }
   
//   public boolean transfer (Account ac, double amt)
//   {
//	   if(amt> this.balance)
//		   return false;
//	   else
//		  this.balance-=amt;
//	   return true;
//   }
//   
   public boolean transfer (Account ac, double amt)
   {
	  boolean result=this.withdraw(amt);
	  if(result==true){
	   ac.deposit(amt);
	    return true;}
	    else
	    	return false;
	    	
   }
   
   
public void addInterest(double rate){
	
	double interest= this.balance*(rate/100);
	       balance+=interest;
	}
  
   public void printDetails()
   {
      System.out.println("ID: " + this.accountID);
      System.out.println("Name: " + name);
      System.out.println("Balance: $" + balance);
      System.out.println("Telephone Number: " + telNo);
      System.out.println(" Tax File Number " + TaxFileNo);
   }

}
