
import java.util.Scanner;

public class AccountDemo
{

   public static void main(String[] args)
   {

      Account acc1 = new Account("A1234", "John", 1000, "12365417");

      
      System.out.println();
      
      Account acc2 = new Account("A9876", "Jane", 2000,"23658479");
      
     
      
      System.out.printf("Account ID: %s Balance: %.2f\n",
                        acc1.getAccountID(), acc1.getBalance());
      
      Account finellasAcc = new Account("A3456", "Finella", 10123, "524879215");
      
      finellasAcc.setTaxFileNumber("123 487 854");
      
     
      double balance = finellasAcc.getBalance();  
      
     // Add taxfile number to John's account
      acc1.setTaxFileNumber("125 125 615");
      
      System.out.println();

      // changing values in an account
      
      // Jane has changed her name to Jill
      
      acc1.printDetails();
      
      
      
      acc2.setName("Jill");
      acc2.setTaxFileNumber("487 569 458");
      acc2.printDetails();
      
      System.out.println();

      acc2.deposit(200);
      acc2.printDetails();
      acc2.transfer(acc1, 200);
      acc1.addInterest(3.5);
      acc2.addInterest(3.5);  
      
      acc1.printDetails();
      System.out.println();

      Scanner sc = new Scanner(System.in);
      int amount;
      
      System.out.print("Enter amount to withdraw: ");
      amount = sc.nextInt();
      
      // attempt to make a withdrawal and trap result that is returned
      boolean result = finellasAcc.withdraw(amount);
      
      // now we need to check the result to see if 
      // the withdrawal was successful or not
      
      if (result == false)
      {
         System.out.printf(
                      "Withdrawal failed - insufficient funds");
      }
      else
      {
         System.out.printf(
                 "Withdrawal successful - remaining balance: $%.2f\n",
                  finellasAcc.getBalance());
      }
      
      

   }

}
