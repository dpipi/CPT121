import java.util.Scanner;

public class MykiExample {
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Select Zone");
		int zone = sc.nextInt();
		while(zone <  1 || zone > 2){
			System.out.println("invalid Zone, Enter a Zone");
			
			 zone = sc.nextInt();
		}
		System.out.println("Enter 1 if 2hrs ticket or 2 if"
				+ " it is Daily");
		int duration = sc.nextInt();
		while(duration <  1 || duration > 2){
			System.out.println("invalid duration, Enter the"
					+ " correct duration");
			
			duration = sc.nextInt();
		}
		
		
		System.out.println("Select 1 for fullfare or "
				+ "2 for Concession");
		int fare_type = sc.nextInt();
		
		while(fare_type <  1 || fare_type > 2){
			System.out.println("invalid fare type , Enter fare_type");
			
			fare_type = sc.nextInt();
		}
		
		
		
		if (zone==1){
			if(duration==1){
				if(fare_type==1){
					System.out.println("$4.40");
				}
				else if (fare_type==2)
					System.out.println("$2.20");
				else 
					System.out.println("Invalid faretype ");
			}
			else if(duration==2)
			{
				if(fare_type==1){
					System.out.println("$8.80");
				}
				else if (fare_type==2)
					System.out.println("$4.40");
				else 
					System.out.println("Invalid faretype ");	
				}
			else 
				System.out.println("Invalid duration ");
			
			
		}
		else if (zone==2){
			if(duration==1){
				if(fare_type==1){
					System.out.println("$3.00");
				}
				else if (fare_type==2)
					System.out.println("$1.50");
				else 
					System.out.println("Invalid faretype ");
			}
			else if(duration==2)
			{
				if(fare_type==1){
					System.out.println("$6.00");
				}
				else if (fare_type==2)
					System.out.println("$3.00");
				else 
					System.out.println("Invalid faretype ");	
				}
			else 
				System.out.println("Invalid duration ");
			
		}
		else
			System.out.println("Invalid Zone ");
			
		sc.close();
		}
	
		
	}
	


