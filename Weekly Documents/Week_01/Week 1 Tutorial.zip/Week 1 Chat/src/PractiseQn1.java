
import java.util.Scanner;
public class PractiseQn1 {
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("what colour is the light?");
		String input = sc.nextLine();
		
				if (input.equalsIgnoreCase("green")) {
					System.out.println("Proceed through intersection");
				}
				else if (input.equalsIgnoreCase("yellow")){
					System.out.println("you must stop unless you "
							+ "can't stop safely ");
				}
				else if (input.equalsIgnoreCase("Red")){
					System.out.print("you must stop and don't go "
							+ "into the intersection ");
				}
				else {
					System.out.println("Invalid input");
	 }
	
	}

}
