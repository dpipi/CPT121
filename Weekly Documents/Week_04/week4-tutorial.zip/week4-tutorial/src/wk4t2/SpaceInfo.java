package wk4t2;

public class SpaceInfo {
	private static final int LEVELS = 3;
	private static final int SPACES_PER_LEVEL = 10; 

	private static final int OCCUPIED = 0;
	private static final int VACANT = 1;
	private final static int OUT_OF_SERVICE = 2;

	// this array declaration needs to be updated
	private static final int [][] carParkSpaces = new int[LEVELS][SPACES_PER_LEVEL];

	// constructor performs initialisation
	public SpaceInfo()
	{
		for(int levelIndex = 0; levelIndex < carParkSpaces.length; levelIndex++)
			for(int spaceNumber = 0; spaceNumber < carParkSpaces[0].length; spaceNumber++)
				carParkSpaces[levelIndex][spaceNumber] = VACANT;

	}

	private int getLevelIndex(char level)
	{
		return level - 'A';
	}

	public boolean spaceEntered(char level, int spaceNumber)
	{
		// Returns true if parking space was initially vacant

		int levelIndex = getLevelIndex(level);

		// Check this space is currently vacant
		if (carParkSpaces[levelIndex][spaceNumber] == VACANT)
		{
			carParkSpaces[levelIndex][spaceNumber] = OCCUPIED;
			return true;
		}
		else
			return false;   
	}

	public boolean spaceVacated(char level, int spaceNumber)
	{
		// fails if space wasn't already occupied
		int levelIndex = getLevelIndex(level);

		// check space was occupied
		if (carParkSpaces[levelIndex][spaceNumber] == OCCUPIED) 
		{
			carParkSpaces[levelIndex][spaceNumber] = VACANT;
			return true;
		}
		else
			return false;
	}

	public void displayCarParkStatus()
	{
		// calculate total number of spaces available
		int levels = carParkSpaces.length;
		int spacesPerLevel = carParkSpaces[0].length;

		int totalSpaces = levels * spacesPerLevel;

		int occupiedSpaces = 0;
		int outOfServiceSpaces = 0;

		// count all occupied spaces and 'in service' spaces across the three levels of the car park
		for (int i = 0; i < carParkSpaces.length; i++)
		{
			for (int j = 0; j < carParkSpaces[i].length; j++)
			{
				if (carParkSpaces[i][j] == OCCUPIED)
				{
					occupiedSpaces++;
				} 
				else
					if (carParkSpaces[i][j] == OUT_OF_SERVICE)
					{
						outOfServiceSpaces++;
					}
			}

			// determine current car park status
			if (occupiedSpaces + outOfServiceSpaces == totalSpaces)
			{
				System.out.println("*** CAR PARK FULL ***");
			}
			else
			{
				System.out.println("*** CAR PARK OPEN ***");
			}

			// display current car park usage stats
			System.out.println("Spaces used: " + occupiedSpaces);
			System.out.println("Spaces available: " + 
					(totalSpaces - (occupiedSpaces + outOfServiceSpaces)));
		}
	}

	public boolean returnSpaceToService(char level, int spaceNumber)
	{
		// fails if space wasn't out of service
		int levelIndex = getLevelIndex(level);

		if (carParkSpaces[levelIndex][spaceNumber] == OUT_OF_SERVICE) {
			carParkSpaces[levelIndex][spaceNumber] = VACANT;
			return true;
		}
		else
			return false;
	}

	public boolean takeSpaceOutOfService(char level, int spaceNumber)
	{
		// Fails if space wasn't currently in service (i.e. vacant)
		// Assume illegal to take an occupied site out of service
		int levelIndex = getLevelIndex(level);

	      if (carParkSpaces[levelIndex][spaceNumber] == VACANT) {
	    	  carParkSpaces[levelIndex][spaceNumber] = OUT_OF_SERVICE;
	    	  return true;
	      }
	      else
	    	  return false;
	}

	public void debugDisplay() {
		// display 2D array for debug purposes

		// column index for 2D array
		System.out.print("    ");
		for (int j = 0; j < carParkSpaces[0].length; j++)
			System.out.printf("%-3d", j);
		System.out.println();

		for (int i = 0; i < carParkSpaces.length; i++) {
			System.out.printf("%-3c", 'A' + i);
			for (int j = 0; j < carParkSpaces[i].length; j++) {
				switch(carParkSpaces[i][j]) {
				case VACANT:
					System.out.print(" - ");
					break;
				case OCCUPIED:
					System.out.print(" X ");
					break;
				case OUT_OF_SERVICE:
					System.out.print(" S ");
					break;
				}

			}
			System.out.println();
		}

	}

}
