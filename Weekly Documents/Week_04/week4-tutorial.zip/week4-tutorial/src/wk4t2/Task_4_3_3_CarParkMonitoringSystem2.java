package wk4t2;
 
import java.util.Scanner;

public class Task_4_3_3_CarParkMonitoringSystem2
{
   private static final int LEVELS = 3;
   private static final int SPACES_PER_LEVEL = 10; 
   
   private static final int OCCUPIED = 0;
   private static final int VACANT = 1;
   private final static int OUT_OF_SERVICE = 2;
   
   // this array declaration needs to be updated
   private static final int [][] carParkSpaces = 
                                     new int[LEVELS][SPACES_PER_LEVEL];
   
   private final static Scanner sc = new Scanner(System.in);
   
   public static void main(String[] args)
   {
      
      String selection;
      
      initialiseCarParkSpaces();
      do
      {
         // display menu options and prompt user for selection
         System.out.println("*** Car Park Monitoring System ***\n");
         System.out.println("A - Record Car Parked");
         System.out.println("B - Record Car Exited");
         System.out.println("C - Display Car Park Status");
         System.out.println("D - Take Parking Space Out of Service");
         System.out.println("E - Return Parking Space to Service (Vacant)");
         System.out.println("F - debug Display");
         System.out.println("X - Exit Program");
         System.out.println();
         
         System.out.print("Enter selection: ");
         System.out.println();
         selection = sc.nextLine().toUpperCase();
              
         // process menu selection and trigger corresponding helper method
         switch(selection)
         {
            case "A":
               if (spaceEntered() == false)
            	   System.out.println("Error - that space was not vacant");
               break;
            case "B":
               if (spaceVacated() == false)
            	   System.out.println("Error - that space wasn't occupied");
               break;
            case "C":
               displayCarParkStatus(carParkSpaces);
               break;
            case "D":
               if (takeSpaceOutOfService() == false)
            	   System.out.println("Error - that space wasn't in service (occupied or vacant)");
               break;
            case "E":
               if (returnSpaceToService() == false)
            	   System.out.println("Error - that space wasn't out of service");
               break;
            case "F":
            	deBugDisplay();
            	break;
            case "X":
            	System.out.println("Goodbye");
            	break;
            default:
               System.out.println("Invalid selection - plese try again");
                  
         }
      } while (!selection.toUpperCase().contentEquals("X"));
   }
   
   private static void initialiseCarParkSpaces() {
	   for(int levelIndex = 0; levelIndex < carParkSpaces.length; levelIndex++)
		   for(int spaceNumber = 0; spaceNumber < carParkSpaces[0].length; spaceNumber++)
			   carParkSpaces[levelIndex][spaceNumber] = VACANT;
   }

   private static int getLevelIndex(char level)
   {
      return level - 'A';
   }
   
   private static boolean spaceEntered()
   {
	   // Returns true if parking space was initially vacant
	   
      System.out.println("Enter level (A, B or C): ");
      char level = sc.nextLine().toUpperCase().charAt(0);
      
      System.out.println("Enter space number (0 - 9)");
      
      //Highlight to students the
      //use of Integer.parseInt so we don't have to worry about
      //newlines when reading an integer
      int spaceNumber = Integer.parseInt(sc.nextLine());
      
      int levelIndex = getLevelIndex(level);

      // Check this space is currently vacant
      if (carParkSpaces[levelIndex][spaceNumber] == VACANT)
      {
          carParkSpaces[levelIndex][spaceNumber] = OCCUPIED;
          return true;
      }
      else
    	  return false;   
   }
   
   private static boolean spaceVacated()
   {
	   // fails if space wasn't already occupied
	   
      System.out.println("Enter level (A, B or C): ");
      char level = sc.nextLine().toUpperCase().charAt(0);
      
      System.out.println("Enter space number (0 - 9");
      int spaceNumber = Integer.parseInt(sc.nextLine());
      
      int levelIndex = getLevelIndex(level);
      
      // check space was occupied
      if (carParkSpaces[levelIndex][spaceNumber] == OCCUPIED) 
      {
    	  carParkSpaces[levelIndex][spaceNumber] = VACANT;
    	  return true;
      }
      else
    	  return false;
   }
   
   public static void displayCarParkStatus(int [][] carParkSpaces)
   {
      // calculate total number of spaces available
      int levels = carParkSpaces.length;
      int spacesPerLevel = carParkSpaces[0].length;
      
      int totalSpaces = levels * spacesPerLevel;
      
      int occupiedSpaces = 0;
      int outOfServiceSpaces = 0;
      
      // count all occupied spaces and 'in service' spaces across the three levels of the car park
      for (int i = 0; i < carParkSpaces.length; i++)
      {
         for (int j = 0; j < carParkSpaces[i].length; j++)
         {
            if (carParkSpaces[i][j] == OCCUPIED)
            {
               occupiedSpaces++;
            } 
            else
            if (carParkSpaces[i][j] == OUT_OF_SERVICE)
            {
               outOfServiceSpaces++;
            }
         }
         
         // determine current car park status
         if (occupiedSpaces + outOfServiceSpaces == totalSpaces)
         {
            System.out.println("*** CAR PARK FULL ***");
         }
         else
         {
            System.out.println("*** CAR PARK OPEN ***");
         }
         
         // display current car park usage stats
         System.out.println("Spaces used: " + occupiedSpaces);
         System.out.println("Spaces available: " + 
                            (totalSpaces - (occupiedSpaces + outOfServiceSpaces)));
      }
   }
   
   private static boolean returnSpaceToService()
   {
	   // fails if space wasn't out of service
	   
      System.out.println("Enter level (A, B or C): ");
      char level = sc.nextLine().toUpperCase().charAt(0);
      
      System.out.println("Enter space number (0 - 9");
      int spaceNumber = Integer.parseInt(sc.nextLine());
      
      int levelIndex = getLevelIndex(level);
       
      if (carParkSpaces[levelIndex][spaceNumber] == OUT_OF_SERVICE) {
    	  carParkSpaces[levelIndex][spaceNumber] = VACANT;
    	  return true;
      }
      else
    	  return false;
   }

   private static boolean takeSpaceOutOfService()
   {
	   // Fails if space wasn't currently in service (i.e. vacant)
	// Assume illegal to take an occupied site out of service
		
      System.out.println("Enter level (A, B or C): ");
      char level = sc.nextLine().toUpperCase().charAt(0);
      
      System.out.println("Enter space number (0 - 9");
      int spaceNumber = Integer.parseInt(sc.nextLine());
      
      int levelIndex = getLevelIndex(level);
           
      if (carParkSpaces[levelIndex][spaceNumber] == VACANT) {
    	  carParkSpaces[levelIndex][spaceNumber] = OUT_OF_SERVICE;
    	  return true;
      }
      else
    	  return false;
   }
   
   private static void deBugDisplay() {
	   // display 2D array for debug purposes
	   
	   // column index for 2D array
	   System.out.print("    ");
	   for (int j = 0; j < carParkSpaces[0].length; j++)
		   System.out.printf("%-3d", j);
	  System.out.println();
	  
	   for (int i = 0; i < carParkSpaces.length; i++) {
		   System.out.printf("%-3c", 'A' + i);
	         for (int j = 0; j < carParkSpaces[i].length; j++) {
	        	 switch(carParkSpaces[i][j]) {
	        	 case VACANT:
	        		 System.out.print(" - ");
	        		 break;
	        	 case OCCUPIED:
	        		 System.out.print(" X ");
	        		 break;
	        	 case OUT_OF_SERVICE:
	        		 System.out.print(" S ");
	        		 break;
	        	 }
	        	
	         }
	         System.out.println();
	   }
	       
   }
}
