package wk4t2;

import java.util.Scanner;

public class Task_4_3_3_CarParkMonitoringSystem3
{
   
   private final static Scanner sc = new Scanner(System.in);
   private final static SpaceInfo myCarPark = new SpaceInfo();
   	   
   public static void main(String[] args)
   {   
	   
	   String selection;
	   
      do
      {
         // display menu options and prompt user for selection
         System.out.println("*** Car Park Monitoring System ***\n");
         System.out.println("A - Record Car Parked");
         System.out.println("B - Record Car Exited");
         System.out.println("C - Display Car Park Status");
         System.out.println("D - Take Parking Space Out of Service");
         System.out.println("E - Return Parking Space to Service (Vacant)");
         System.out.println("F - debug Display");
         System.out.println("X - Exit Program");
         System.out.println();
         
         System.out.print("Enter selection: ");
         System.out.println();
         selection = sc.nextLine().toUpperCase();
              
         // process menu selection and trigger corresponding helper method
         switch(selection)
         {
            case "A":
               if (spaceEntered() == false)
            	   System.out.println("Error - that space was not vacant");
               break;
            case "B":
               if (spaceVacated() == false)
            	   System.out.println("Error - that space wasn't occupied");
               break;
            case "C":
            	myCarPark.displayCarParkStatus();
               break;
            case "D":
               if (takeSpaceOutOfService() == false)
            	   System.out.println("Error - that space wasn't in service (occupied or vacant)");
               break;
            case "E":
               if ( returnSpaceToService() == false)
            	   System.out.println("Error - that space wasn't out of service");
               break;
            case "F":
            	myCarPark.debugDisplay();;
            	break;
            case "X":
            	System.out.println("Goodbye");
            	break;
            default:
               System.out.println("Invalid selection - please try again");
                  
         }
      } while (!selection.toUpperCase().contentEquals("X"));
   }
   	
	
	private static boolean spaceEntered()
	{
		// Returns true if parking space was initially vacant
		System.out.println("Enter level (A, B or C): ");
		char level = sc.nextLine().toUpperCase().charAt(0);

		System.out.println("Enter space number (0 - 9)");

		//Highlight to students the
		//use of Integer.parseInt so we don't have to worry about
		//newlines when reading an integer
		int spaceNumber = Integer.parseInt(sc.nextLine());

		
		return myCarPark.spaceEntered(level,spaceNumber);  
	}

	private static boolean spaceVacated()
	{
		// fails if space wasn't already occupied

		System.out.println("Enter level (A, B or C): ");
		char level = sc.nextLine().toUpperCase().charAt(0);

		System.out.println("Enter space number (0 - 9");
		int spaceNumber = Integer.parseInt(sc.nextLine());

		return myCarPark.spaceVacated(level,spaceNumber);
	}

	private static boolean takeSpaceOutOfService()
	{
		// fails if space wasn't already occupied

		System.out.println("Enter level (A, B or C): ");
		char level = sc.nextLine().toUpperCase().charAt(0);

		System.out.println("Enter space number (0 - 9");
		int spaceNumber = Integer.parseInt(sc.nextLine());

		return myCarPark.takeSpaceOutOfService(level,spaceNumber);
	}

	private static boolean returnSpaceToService()
	{
		// fails if space wasn't already occupied

		System.out.println("Enter level (A, B or C): ");
		char level = sc.nextLine().toUpperCase().charAt(0);

		System.out.println("Enter space number (0 - 9");
		int spaceNumber = Integer.parseInt(sc.nextLine());

		return myCarPark.returnSpaceToService(level,spaceNumber);
	}

}
